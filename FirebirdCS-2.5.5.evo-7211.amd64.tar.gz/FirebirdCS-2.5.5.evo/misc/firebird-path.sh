# /etc/profile.d/firebird-path.sh
#
# Added the /opt/firebird/bin directory to the start of the system
# path only if it's not already in there.  -- SJF 2016/09/19


FIREBIRD_BIN=/opt/firebird/bin

echo $PATH | fgrep -q $FIREBIRD_BIN || {
	# echo Adding to path

	export PATH=$FIREBIRD_BIN:$PATH
}
